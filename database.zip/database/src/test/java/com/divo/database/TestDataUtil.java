package com.divo.database;

import com.divo.database.domain.Brands;
import com.divo.database.domain.Products;

public class TestDataUtil 
{
    public static Brands createTestBrand()
    {
        return Brands.builder()
                .brand_name("sunlight")
                .build();  
    }
    
        public static Products createTestProduct(final Brands brand)
    {
        return Products.builder()
                .product_name("wgr")
                .categiryID(1)
                .imageURL("sfef")
                .brand(brand)
                .specifications("fssef")
                .description("fsguhjsfe")
                .build();
                
    }
}
