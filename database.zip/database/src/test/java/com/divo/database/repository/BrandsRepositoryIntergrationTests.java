package com.divo.database.repository;
import com.divo.database.TestDataUtil;
import com.divo.database.domain.Brands;
import java.util.Optional;
import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@SpringBootTest
@ExtendWith(SpringExtension.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class BrandsRepositoryIntergrationTests 
{
        private BrandsRepository underTest;
    
    @Autowired
    public BrandsRepositoryIntergrationTests(BrandsRepository underTest)
    {
        this.underTest=underTest;
    }
    
    @Test
    public void testThatBrandCanBeCreatedAndRecalled()
    {
        Brands brand = TestDataUtil.createTestBrand();
        underTest.save(brand);
        Optional<Brands> result = underTest.findById(brand.getBrandID());
        assertThat(result).isPresent();
        assertThat(result.get()).isEqualTo(brand);
    }
}
