//package com.divo.database.repository;
//
//import com.divo.database.TestDataUtil;
//import com.divo.database.domain.Brands;
//import com.divo.database.domain.Products;
//import java.util.Optional;
//import static org.assertj.core.api.Assertions.assertThat;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.annotation.DirtiesContext;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//
//@SpringBootTest
//@ExtendWith(SpringExtension.class)
//@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
//public class ProductsRepositoryIntergrationTests
//{
//    private ProductsRepository underTest;
//    
//    @Autowired
//    public ProductsRepositoryIntergrationTests(ProductsRepository underTest)
//    {
//        this.underTest=underTest;
//    }
//    
//    @Test
//    public void testThatProuductCanBeCreatedAndRecalled()
//    {
//        Products product = TestDataUtil.createTestProduct();
//        underTest.save(product);
//        Optional<Products> result = underTest.findById(product.getProductID());
//        assertThat(result).isPresent();
//        assertThat(result.get()).isEqualTo(product);
//    }
//}
