package com.divo.database.repository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.divo.database.domain.Review;

@Repository
public interface ReviewRepository extends CrudRepository<Review,Integer>
{
    
}
