package com.divo.database.services.Impl;

import com.divo.database.domain.Products;
import com.divo.database.repository.ProductsRepository;
import com.divo.database.services.ProductsService;
import org.springframework.stereotype.Service;

@Service
public class ProductsServiceImpl implements ProductsService
{

    private ProductsRepository productsRepository;

    public ProductsServiceImpl(ProductsRepository productsRepository) 
    {
        this.productsRepository = productsRepository;
    }
    
    @Override
    public Products createProduct(Products product) 
    {
        return productsRepository.save(product);
    }
    
}
