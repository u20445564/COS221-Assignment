package com.divo.database.repository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.divo.database.domain.ProductCategory;

@Repository
public interface productCategoryRepository extends CrudRepository<ProductCategory,Integer>
{
    
}
