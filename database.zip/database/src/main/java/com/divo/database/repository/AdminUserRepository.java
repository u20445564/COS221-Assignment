package com.divo.database.repository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.divo.database.domain.AdminUser;

@Repository
public interface AdminUserRepository extends CrudRepository<AdminUser,Integer>
{
    
}
