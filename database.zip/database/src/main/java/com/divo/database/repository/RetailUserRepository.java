package com.divo.database.repository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.divo.database.domain.RetailUser;


@Repository
public interface RetailUserRepository extends CrudRepository<RetailUser,Integer>
{
    
}
