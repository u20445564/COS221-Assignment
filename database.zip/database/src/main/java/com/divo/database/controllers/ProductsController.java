package com.divo.database.controllers;

import com.divo.database.domain.Brands;
import com.divo.database.domain.Products;
import com.divo.database.domain.dto.BrandsDto;
import com.divo.database.domain.dto.ProductsDto;
import com.divo.database.mappers.Mapper;
import com.divo.database.services.BrandsService;
import com.divo.database.services.ProductsService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class ProductsController 
{
   private ProductsService productsService;
    
    private Mapper<Products,ProductsDto> productsMapper;
    public ProductsController(ProductsService productsService,Mapper<Products,ProductsDto> productsMapper)
    {
        this.productsService= productsService;
        this.productsMapper=productsMapper;
    }
    
    @PostMapping(path="/products")
    public ResponseEntity<ProductsDto> createProduct(@RequestBody ProductsDto productDto)
    {
        Products product = productsMapper.mapFrom(productDto);
        Products savedProduct = productsService.createProduct(product);
        ProductsDto result =productsMapper.mapTO(savedProduct);
        return new ResponseEntity<>(result,HttpStatus.CREATED);
    }

    
}
