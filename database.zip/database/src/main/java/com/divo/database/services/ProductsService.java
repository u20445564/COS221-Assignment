package com.divo.database.services;

import com.divo.database.domain.Products;


public interface ProductsService 
{
    Products createProduct(Products product);
}
