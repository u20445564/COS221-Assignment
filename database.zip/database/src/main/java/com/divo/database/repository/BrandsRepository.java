package com.divo.database.repository;

import com.divo.database.domain.Brands;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author School
 */
@Repository
public interface BrandsRepository extends CrudRepository<Brands,Integer>
{
    
}
