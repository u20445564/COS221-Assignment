package com.divo.database.repository;

import com.divo.database.domain.Brands;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


@Repository
public interface BrandsRepository extends JpaRepository<Brands,Integer>
{
    @Modifying
    @Transactional
    @Query(value = "INSERT INTO brands (brand_name) VALUES (?1)", nativeQuery = true)
    void createBrand(String brand_name);
    
    @Query("SELECT b FROM Brands b WHERE b.brandID = ?1")
    Brands findBrandById(Integer brandID);
    
    @Query(value = "INSERT INTO brands (brand_name) VALUES (?1) RETURNING brandid", nativeQuery = true)
    Integer createBrandAndReturnId(String brand_name);
}
