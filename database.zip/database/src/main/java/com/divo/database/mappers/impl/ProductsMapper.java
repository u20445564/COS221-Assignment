package com.divo.database.mappers.impl;

import com.divo.database.domain.Products;
import com.divo.database.domain.dto.ProductsDto;
import com.divo.database.mappers.Mapper;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
public class ProductsMapper implements Mapper<Products,ProductsDto> 
{

    private ModelMapper modelMapper;
    
    public ProductsMapper(ModelMapper modelMapper)
    {
        this.modelMapper=modelMapper;
    }
    
    @Override
    public ProductsDto mapTO(Products a) 
    {
         return modelMapper.map(a, ProductsDto.class);
    }

    @Override
    public Products mapFrom(ProductsDto b) 
    {
        return modelMapper.map(b,Products.class);
    }
    
}
