package com.divo.database.controllers;

import com.divo.database.domain.Brands;
import com.divo.database.domain.dto.BrandsDto;
import com.divo.database.mappers.Mapper;
import com.divo.database.services.BrandsService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class BrandController 
{
    
    private BrandsService brandsService;
    
    private Mapper<Brands,BrandsDto> brandsMapper;
    public BrandController(BrandsService brandsService,Mapper<Brands,BrandsDto> brandsMapper)
    {
        this.brandsService= brandsService;
        this.brandsMapper=brandsMapper;
    }
            
    @PostMapping(path ="/brands")
    public BrandsDto createBrand(@RequestBody BrandsDto brand)
    {
        Brands brandEntity = brandsMapper.mapFrom(brand);
        Brands savedBrand = brandsService.createBrand(brandEntity);
        return brandsMapper.mapTO(savedBrand);
    }
    
}
