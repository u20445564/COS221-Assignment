package com.divo.database.controllers;

import com.divo.database.domain.Brands;
import com.divo.database.domain.dto.BrandsDto;
import com.divo.database.mappers.Mapper;
import com.divo.database.services.BrandsService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class BrandController 
{
    
    private BrandsService brandsService;
    
    private Mapper<Brands,BrandsDto> brandsMapper;
    public BrandController(BrandsService brandsService,Mapper<Brands,BrandsDto> brandsMapper)
    {
        this.brandsService= brandsService;
        this.brandsMapper=brandsMapper;
    }
            
    @PostMapping(path ="/brands")
    public ResponseEntity<Brands> createBrand(@RequestBody BrandsDto brandDto) 
    {
        Brands brand = brandsMapper.mapFrom(brandDto);
        Brands createdBrand = brandsService.createBrand(brand);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdBrand);
    }
    
}
