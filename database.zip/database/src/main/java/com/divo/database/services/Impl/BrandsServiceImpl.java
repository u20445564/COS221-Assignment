package com.divo.database.services.Impl;

import com.divo.database.domain.Brands;
import com.divo.database.repository.BrandsRepository;
import com.divo.database.services.BrandsService;
import org.springframework.stereotype.Service;

@Service
public class BrandsServiceImpl implements BrandsService
{

    private  BrandsRepository brandsRepository;
    
    public BrandsServiceImpl(BrandsRepository brandsRepository)
    {
        this.brandsRepository=brandsRepository;
    }
    @Override
    public Brands createBrand(Brands brand) 
    {
        return brandsRepository.save(brand);
    }
    
}
