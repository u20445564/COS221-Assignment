package com.divo.database.services.Impl;

import com.divo.database.domain.Brands;
import com.divo.database.repository.BrandsRepository;
import com.divo.database.services.BrandsService;
import jakarta.transaction.Transactional;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class BrandsServiceImpl implements BrandsService
{

    private  BrandsRepository brandsRepository;
    
    public BrandsServiceImpl(BrandsRepository brandsRepository)
    {
        this.brandsRepository=brandsRepository;
    }
    @Override
    @Transactional
    public Brands createBrand(Brands brand) 
    {
        Integer newId = brandsRepository.createBrandAndReturnId(brand.getBrand_name());
        return brandsRepository.findBrandById(newId);
    }
    
}
