package com.divo.database.mappers.impl;

import com.divo.database.domain.Brands;
import com.divo.database.domain.dto.BrandsDto;
import com.divo.database.mappers.Mapper;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
public class BrandsMapper implements Mapper<Brands,BrandsDto>
{

    private ModelMapper modelMapper;
    
    public BrandsMapper(ModelMapper modelMapper)
    {
        this.modelMapper=modelMapper;
    }
    
    @Override
    public BrandsDto mapTO(Brands a) 
    {
        return modelMapper.map(a, BrandsDto.class);
    }

    @Override
    public Brands mapFrom(BrandsDto b) 
    {
        return modelMapper.map(b,Brands.class);
    }
    
}
