package com.divo.database.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProductsDto 
{
    private Integer productID;
    
    private String product_name;
    
    private String description;
    
    private BrandsDto brand;
    
    private Integer categiryID;
    
    private String imageURL;
    
    private String specifications;   
    
    private int productsID;
}
