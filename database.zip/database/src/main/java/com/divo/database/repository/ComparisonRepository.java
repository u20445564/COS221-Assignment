package com.divo.database.repository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.divo.database.domain.Comparison;

@Repository
public interface ComparisonRepository extends CrudRepository<Comparison,Integer>
{
    
}
