package com.divo.database.services;

import com.divo.database.domain.Brands;


public interface BrandsService 
{
    Brands createBrand(Brands brand);

}
